from pathlib import Path

DATASET_PATH = Path("/PATH/TO/DATASETS")
